const p1display = document.querySelector("#p1display");
const p2display = document.querySelector("#p2display");
const p1button = document.querySelector("#p1button");
const p2button = document.querySelector("#p2button");
const resetButton = document.querySelector("#reset");
const winningScoreSelect = document.querySelector('#playto');

let p1score = 0;
let p2score = 0;
let WinScore = 3;
let isGameOver = false;

p1button.addEventListener('click', function () {
    if (!isGameOver) {
        p1score += 1;
        if (p1score === WinScore) {
            isGameOver = true;
            p1display.classList.add('has-text-success');
            p2display.classList.add('has-text-danger');
            p1button.disabled = true;
            p2button.disabled = true;
        }
        p1display.textContent = p1score;
    }
}
);
p2button.addEventListener('click', function () {
    if (!isGameOver) {
        p2score += 1;
        if (p2score === WinScore) {
            isGameOver = true;
            p2display.classList.add('has-text-success');
            p1display.classList.add('has-text-danger');
            p1button.disabled = true;
            p2button.disabled = true;
        }
        p2display.textContent = p2score;
    }
}
);
winningScoreSelect.addEventListener('change', function () {
    WinScore = parseInt(this.value);
    reset();
});
resetButton.addEventListener('click', reset);
function reset() {
    isGameOver = false;
    p1score = 0;
    p2score = 0;
    p1display.textContent = 0;
    p2display.textContent = 0;
    p1display.classList.remove('winner', 'loser');
    p2display.classList.remove('winner', 'loser');
    p1button.disabled = false;
    p2button.disabled = false;
};






